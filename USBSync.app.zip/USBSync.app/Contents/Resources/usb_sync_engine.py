#!/usr/bin/env python3
import os, sys, shutil, datetime, logging, unicodedata

def setup_logger(usb_path, opt_v):
    logger = logging.getLogger("USBSync")
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s  %(levelname)-8s  %(message)s",
                            datefmt="%Y-%m-%d %H:%M:%S")
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    if opt_v:
        parts = usb_path.split("/")
        usb_root = "/" + "/".join(parts[1:3]) if len(parts) >= 3 else usb_path
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        log_path = os.path.join(usb_root, f"USBSync_Log_{ts}.txt")
        try:
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setFormatter(fmt)
            logger.addHandler(fh)
            logger.info(f"Log-Datei: {log_path}")
        except Exception as e:
            logger.warning(f"Log konnte nicht erstellt werden: {e}")
    return logger

def norm(name):
    return unicodedata.normalize("NFC", name).lower()

def find_folders(mac_root, target_name):
    target_norm = norm(target_name)
    found = []
    queue = [mac_root]
    while queue:
        current = queue.pop(0)
        try:
            entries = sorted(os.scandir(current), key=lambda e: e.name.lower())
        except (PermissionError, OSError):
            continue
        for entry in entries:
            if not entry.is_dir(follow_symlinks=False):
                continue
            if norm(entry.name) == target_norm:
                found.append(entry.path)
            else:
                queue.append(entry.path)
    return found

def copy_tree(src, dst, opt_e, opt_l, opt_newer, logger, stats):
    try:
        os.makedirs(dst, exist_ok=True)
    except Exception as e:
        logger.error(f"FEHLER Ordner erstellen {dst}: {e}")
        stats["errors"] += 1
        return
    try:
        entries = sorted(os.scandir(src), key=lambda e: e.name.lower())
    except (PermissionError, OSError) as e:
        logger.error(f"Kein Lesezugriff: {src} ({e})")
        stats["errors"] += 1
        return
    for entry in entries:
        if entry.name.startswith("."):
            continue
        s = entry.path
        d = os.path.join(dst, entry.name)
        if entry.is_dir(follow_symlinks=False):
            if not os.path.isdir(d):
                logger.info(f"ORDNER ERSTELLT: {d}")
                stats["dirs_created"] = stats.get("dirs_created", 0) + 1
            copy_tree(s, d, opt_e, opt_l, opt_newer, logger, stats)
        else:
            exists = os.path.exists(d)
            # opt_newer: Quelldatei älter als Zieldatei -> ueberspringen
            if exists and opt_newer:
                src_mtime = os.path.getmtime(s)
                dst_mtime = os.path.getmtime(d)
                if src_mtime <= dst_mtime:
                    import datetime as dt
                    src_ts = dt.datetime.fromtimestamp(src_mtime).strftime("%Y-%m-%d %H:%M")
                    dst_ts = dt.datetime.fromtimestamp(dst_mtime).strftime("%Y-%m-%d %H:%M")
                    logger.info(f"  ÄLTER -- uebersprungen: {entry.name}  (USB:{src_ts} <= Mac:{dst_ts})")
                    stats["older"] = stats.get("older", 0) + 1
                    stats.setdefault("older_files", []).append(entry.name)
                    print(f"OLDER:{entry.name}", flush=True)
                    continue
            if exists and not opt_e:
                logger.info(f"  ÜBERSPRUNGEN (vorhanden): {d}")
                stats["skipped"] += 1
            else:
                try:
                    # Datei kopieren: copy() statt copy2() vermeidet
                    # problematische Extended Attributes (xattr) die auf macOS
                    # Backslashes in Dateinamen verursachen koennen
                    src_clean = os.path.normpath(s)
                    dst_clean = os.path.normpath(d)
                    shutil.copy(src_clean, dst_clean)
                    # Nur Zeitstempel uebertragen, keine xattr
                    src_stat = os.stat(src_clean)
                    os.utime(dst_clean, (src_stat.st_atime, src_stat.st_mtime))
                    if exists:
                        logger.info(f"  ERSETZT: {dst_clean}")
                        stats["replaced"] = stats.get("replaced", 0) + 1
                    else:
                        logger.info(f"  KOPIERT: {dst_clean}")
                        stats["copied"] += 1
                    if opt_l:
                        try:
                            os.remove(s)
                            logger.info(f"  GELÖSCHT (USB): {s}")
                            stats["deleted"] += 1
                        except Exception as e:
                            logger.error(f"  FEHLER Löschen {s}: {e}")
                            stats["errors"] += 1
                except Exception as e:
                    logger.error(f"  FEHLER Kopieren {s}: {e}")
                    stats["errors"] += 1
    if opt_l:
        for dirpath, dirnames, filenames in os.walk(src, topdown=False):
            if dirpath == src:
                continue
            if not os.listdir(dirpath):
                try:
                    os.rmdir(dirpath)
                    logger.info(f"ORDNER GELÖSCHT (USB): {dirpath}")
                    stats["deleted"] += 1
                except Exception as e:
                    logger.error(f"FEHLER Ordner löschen {dirpath}: {e}")

def sync(usb_path, mac_path, opt_e, opt_v, opt_l, opt_n=False, opt_newer=False):
    usb_path = os.path.normpath(usb_path)
    mac_path = os.path.normpath(mac_path)
    logger = setup_logger(usb_path, opt_v)
    stats = {"copied": 0, "replaced": 0, "skipped": 0,
             "deleted": 0, "dirs_created": 0, "errors": 0,
             "older": 0, "older_files": []}

    if not os.path.isdir(usb_path):
        logger.error(f"USB-Pfad nicht gefunden: {usb_path}")
        print("RESULT:0:0:0:0:1", flush=True); return
    if not os.path.isdir(mac_path):
        logger.error(f"Mac-Pfad nicht gefunden: {mac_path}")
        print("RESULT:0:0:0:0:1", flush=True); return

    logger.info("=== USB Sync gestartet ===")
    logger.info(f"USB: {usb_path}")
    logger.info(f"MAC: {mac_path}")
    logger.info(f"Optionen: E={opt_e} V={opt_v} L={opt_l} N={opt_n} NUR_NEUER={opt_newer}")

    total_files = sum(len(files) for _, _, files in os.walk(usb_path))
    print(f"TOTAL:{total_files}", flush=True)
    logger.info(f"Dateien gesamt: {total_files}")

    try:
        usb_entries = sorted(os.scandir(usb_path), key=lambda e: e.name.lower())
    except (PermissionError, OSError) as e:
        logger.error(f"Kann USB-Pfad nicht lesen: {e}")
        print("RESULT:0:0:0:0:1", flush=True); return

    not_found = []
    reported  = set()

    for entry in usb_entries:
        name = entry.name
        if name.startswith("."):
            continue

        if entry.is_dir(follow_symlinks=False):
            logger.info(f"")
            logger.info(f"--- Suche Ordner: '{name}' ---")
            print(f"SEARCHING:{name}", flush=True)
            targets = find_folders(mac_path, name)

            if targets:
                for dst in targets:
                    logger.info(f"  GEFUNDEN: {dst}")
                    print(f"SYNCING:{name}", flush=True)
                    copy_tree(entry.path, dst, opt_e, opt_l, opt_newer, logger, stats)
            else:
                if opt_n:
                    dst = os.path.join(mac_path, name)
                    logger.info(f"  NICHT GEFUNDEN -- wird in Mac-Ziel kopiert: '{name}'")
                    print(f"NOTFOUND_COPIED:{name}", flush=True)
                    copy_tree(entry.path, dst, opt_e, opt_l, opt_newer, logger, stats)
                else:
                    logger.warning(f"  NICHT GEFUNDEN -- uebersprungen: '{name}'")
                    print(f"NOTFOUND:{name}", flush=True)
                    not_found.append(name)

        else:
            if name in reported:
                continue
            reported.add(name)
            if opt_n:
                dst = os.path.join(mac_path, name)
                exists = os.path.exists(dst)
                if exists and not opt_e:
                    logger.info(f"  ÜBERSPRUNGEN (vorhanden): {dst}")
                    stats["skipped"] += 1
                else:
                    # Alters-Check fuer Root-Dateien
                    if exists and opt_newer:
                        import datetime as dt
                        src_mtime = os.path.getmtime(entry.path)
                        dst_mtime = os.path.getmtime(dst)
                        if src_mtime <= dst_mtime:
                            src_ts = dt.datetime.fromtimestamp(src_mtime).strftime("%Y-%m-%d %H:%M")
                            dst_ts = dt.datetime.fromtimestamp(dst_mtime).strftime("%Y-%m-%d %H:%M")
                            logger.info(f"  ÄLTER -- uebersprungen: {name}  (USB:{src_ts} <= Mac:{dst_ts})")
                            stats["older"] = stats.get("older", 0) + 1
                            stats.setdefault("older_files", []).append(name)
                            print(f"OLDER:{name}", flush=True)
                            continue
                    try:
                        src_p = os.path.normpath(entry.path)
                        dst_p = os.path.normpath(dst)
                        shutil.copy(src_p, dst_p)
                        src_st = os.stat(src_p)
                        os.utime(dst_p, (src_st.st_atime, src_st.st_mtime))
                        if exists:
                            logger.info(f"  ERSETZT (Root-Datei): {dst}")
                            stats["replaced"] += 1
                        else:
                            logger.info(f"  KOPIERT (Root-Datei): {dst}")
                            stats["copied"] += 1
                        print(f"NOTFOUND_COPIED:{name}", flush=True)
                    except Exception as e:
                        logger.error(f"  FEHLER Root-Datei {name}: {e}")
                        stats["errors"] += 1
            else:
                logger.warning(f"  NICHT GEFUNDEN (Root-Datei) -- uebersprungen: '{name}'")
                print(f"NOTFOUND:{name}", flush=True)
                not_found.append(name)

    logger.info("")
    logger.info("=== Zusammenfassung ===")
    logger.info(f"Kopiert:       {stats['copied']}")
    logger.info(f"Ersetzt:       {stats.get('replaced',0)}")
    logger.info(f"Übersprungen: {stats['skipped']}")
    logger.info(f"Gelöscht:     {stats['deleted']}")
    logger.info(f"Fehler:        {stats['errors']}")

    if not_found:
        logger.warning("")
        if opt_n:
            logger.warning("Folgende Dateien/Ordner wurden nicht im Mac-Ziel-Pfad")
            logger.warning("gefunden — nicht kopiert:")
        else:
            logger.warning("Folgende Dateien/Ordner wurden nicht im Mac-Ziel-Pfad gefunden:")
        for item in not_found:
            logger.warning(f"  * {item}")
        logger.warning("")
        print(f"NOTFOUND_LIST:{'|'.join(not_found)}", flush=True)

    older = stats.get("older_files", [])
    if older:
        logger.warning("")
        logger.warning("Folgende Dateien auf dem USB-Stick sind älter oder")
        logger.warning("genauso alt wie auf dem Mac — nicht kopiert:")
        for item in older:
            logger.warning(f"  * {item}")
        logger.warning("")
        print("OLDER_LIST\t" + "|".join(older), flush=True)

    logger.info("=== USB Sync beendet ===")
    print(f"RESULT:{stats['copied']}:{stats.get('replaced',0)}:{stats['skipped']}:{stats['deleted']}:{stats['errors']}", flush=True)

if __name__ == "__main__":
    if len(sys.argv) not in (6, 7, 8):
        print("Usage: usb_sync_engine.py <usb> <mac> <e:0|1> <v:0|1> <l:0|1> [n:0|1] [newer:0|1]")
        sys.exit(1)
    opt_n     = (sys.argv[6] == "1") if len(sys.argv) >= 7 else False
    opt_newer = (sys.argv[7] == "1") if len(sys.argv) >= 8 else False
    sync(sys.argv[1], sys.argv[2],
         sys.argv[3]=="1", sys.argv[4]=="1", sys.argv[5]=="1",
         opt_n, opt_newer)

